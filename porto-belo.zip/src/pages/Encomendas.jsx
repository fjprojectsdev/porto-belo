import React from 'react'

export default function Encomendas(){
  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-2xl mb-4">Encomendas</h2>
      <p>Lista de encomendas estará aqui. Admin poderá marcar como entregue.</p>
    </div>
  )
}
