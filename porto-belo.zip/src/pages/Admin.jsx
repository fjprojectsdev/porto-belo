import React from 'react'

export default function Admin(){
  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl mb-4">Painel Administrativo</h2>
      <p>Aqui você gerencia comunicados, encomendas, usuários e sugestões.</p>
    </div>
  )
}
