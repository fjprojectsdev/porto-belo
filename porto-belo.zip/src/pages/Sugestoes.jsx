import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Sugestoes(){
  const [form, setForm] = useState({ nome: '', bloco: '', apartamento: '', telefone: '', mensagem: '' })
  const [status, setStatus] = useState('')

  async function handleSubmit(e){
    e.preventDefault()
    setStatus('Enviando...')
    const user = null // replace: supabase.auth.getUser() in production
    const profile_id = user?.id || null

    const { error } = await supabase.from('sugestoes').insert([{ ...form, profile_id }])
    if (error) {
      setStatus('Erro ao enviar: ' + error.message)
      return
    }
    setStatus('Sugestão enviada. Obrigado!')
    setForm({ nome: '', bloco: '', apartamento: '', telefone: '', mensagem: '' })
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl mb-4">Caixa de Sugestões</h2>
      <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow">
        <input className="w-full p-2 border mb-2" placeholder="Seu nome" value={form.nome} onChange={e=>setForm({...form, nome: e.target.value})} />
        <div className="flex gap-2 mb-2">
          <input className="flex-1 p-2 border" placeholder="Bloco" value={form.bloco} onChange={e=>setForm({...form, bloco: e.target.value})} />
          <input className="w-32 p-2 border" placeholder="Apto" value={form.apartamento} onChange={e=>setForm({...form, apartamento: e.target.value})} />
        </div>
        <input className="w-full p-2 border mb-2" placeholder="Telefone" value={form.telefone} onChange={e=>setForm({...form, telefone: e.target.value})} />
        <textarea className="w-full p-2 border mb-2" placeholder="Mensagem" value={form.mensagem} onChange={e=>setForm({...form, mensagem: e.target.value})} />
        <div className="text-right"><button className="px-4 py-2 bg-blue-600 text-white rounded">Enviar</button></div>
        <p className="mt-2 text-sm text-gray-600">{status}</p>
      </form>
    </div>
  )
}
