import React from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <Card title="Encomendas" to="/encomendas" />
      <Card title="Comunicados" to="#" />
      <Card title="Serviços" to="#" />
      <Card title="Classificados" to="#" />
      <Card title="Sugestões" to="/sugestoes" />
    </div>
  )
}

function Card({title, to}){
  return (
    <Link to={to} className="block p-6 bg-white rounded shadow hover:shadow-md">
      <h3 className="text-lg font-medium">{title}</h3>
    </Link>
  )
}
