import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Sugestoes from './pages/Sugestoes'
import Encomendas from './pages/Encomendas'
import Admin from './pages/Admin'

export default function App(){ 
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-slate-50">
        <header className="p-4 bg-white shadow">
          <div className="container mx-auto flex justify-between items-center">
            <h1 className="text-xl font-semibold">Porto Belo</h1>
            <nav className="space-x-4">
              <Link to="/">Home</Link>
              <Link to="/encomendas">Encomendas</Link>
              <Link to="/sugestoes">Sugestões</Link>
              <Link to="/admin">Admin</Link>
            </nav>
          </div>
        </header>
        <main className="container mx-auto p-6">
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/encomendas" element={<Encomendas/>} />
            <Route path="/sugestoes" element={<Sugestoes/>} />
            <Route path="/admin" element={<Admin/>} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}
